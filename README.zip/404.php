<?php
require_once('lib/model.php');
?>
<?php require('website/views/shared/header.php'); ?>
<div class="product-model">
<nav class="navbar navbar-inverse" role="navigation">
    <div class="container">

        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="."><i class="glyphicon glyphicon-home"></i> Shop.vn</a>
        </div>
    </div><!-- /.container-fluid -->
</nav>

<div class="container" style="min-height: 200px">
    <h1>Nội dung không tìm thấy !</h1><br>

    <h5>Nội dung bạn cần xem không có hoặc đã bị xóa bỏ. Quý khách vui lòng xem nội dung khác</h5><br>

    <h5> Chúng tôi xin lỗi nếu việc này làm bạn không hài lòng!</h5>
</div>
</div>
<?php require('website/views/shared/footer.php'); ?>
