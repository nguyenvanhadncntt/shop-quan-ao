<?php
session_unset();
header('location:admin.php');